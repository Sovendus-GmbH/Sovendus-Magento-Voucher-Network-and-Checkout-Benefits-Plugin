export const sovReqTokenKey = "sovReqToken";
export const sovReqProductIdKey = "sovReqProductId";
export const optimizeDomain = "https://www.sovopt.com/";
