var __async = (__this, __arguments, generator) => {
  return new Promise((resolve, reject) => {
    var fulfilled = (value) => {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    };
    var rejected = (value) => {
      try {
        step(generator.throw(value));
      } catch (e) {
        reject(e);
      }
    };
    var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
    step((generator = generator.apply(__this, __arguments)).next());
  });
};
(function() {
  "use strict";
  var CountryCodes = /* @__PURE__ */ ((CountryCodes2) => {
    CountryCodes2["AT"] = "AT";
    CountryCodes2["BE"] = "BE";
    CountryCodes2["DK"] = "DK";
    CountryCodes2["FI"] = "FI";
    CountryCodes2["FR"] = "FR";
    CountryCodes2["DE"] = "DE";
    CountryCodes2["IE"] = "IE";
    CountryCodes2["IT"] = "IT";
    CountryCodes2["NL"] = "NL";
    CountryCodes2["NO"] = "NO";
    CountryCodes2["PL"] = "PL";
    CountryCodes2["PT"] = "PT";
    CountryCodes2["ES"] = "ES";
    CountryCodes2["SE"] = "SE";
    CountryCodes2["CH"] = "CH";
    CountryCodes2["GB"] = "GB";
    return CountryCodes2;
  })(CountryCodes || {});
  const LANGUAGES_BY_COUNTRIES = {
    [
      "AT"
      /* AT */
    ]: { [
      "DE"
      /* DE */
    ]: "Austria" },
    [
      "BE"
      /* BE */
    ]: {
      [
        "FR"
        /* FR */
      ]: "Belgium French",
      [
        "NL"
        /* NL */
      ]: "Belgium Dutch"
    },
    [
      "DK"
      /* DK */
    ]: { [
      "DA"
      /* DA */
    ]: "Denmark" },
    [
      "FI"
      /* FI */
    ]: { [
      "FI"
      /* FI */
    ]: "Finland" },
    [
      "FR"
      /* FR */
    ]: { [
      "FR"
      /* FR */
    ]: "France" },
    [
      "DE"
      /* DE */
    ]: { [
      "DE"
      /* DE */
    ]: "Germany" },
    [
      "IE"
      /* IE */
    ]: { [
      "EN"
      /* EN */
    ]: "Ireland" },
    [
      "IT"
      /* IT */
    ]: { [
      "IT"
      /* IT */
    ]: "Italy" },
    [
      "NL"
      /* NL */
    ]: { [
      "NL"
      /* NL */
    ]: "Netherlands" },
    [
      "NO"
      /* NO */
    ]: { [
      "NB"
      /* NB */
    ]: "Norway" },
    [
      "PL"
      /* PL */
    ]: { [
      "PL"
      /* PL */
    ]: "Poland" },
    [
      "PT"
      /* PT */
    ]: { [
      "PT"
      /* PT */
    ]: "Portugal" },
    [
      "ES"
      /* ES */
    ]: { [
      "ES"
      /* ES */
    ]: "Spain" },
    [
      "SE"
      /* SE */
    ]: { [
      "SV"
      /* SV */
    ]: "Sweden" },
    [
      "CH"
      /* CH */
    ]: {
      [
        "FR"
        /* FR */
      ]: "Switzerland French",
      [
        "DE"
        /* DE */
      ]: "Switzerland German",
      [
        "IT"
        /* IT */
      ]: "Switzerland Italian"
    },
    [
      "GB"
      /* GB */
    ]: { [
      "EN"
      /* EN */
    ]: "United Kingdom" }
  };
  const sovReqTokenKey = "sovReqToken";
  const sovReqProductIdKey = "sovReqProductId";
  function handleCheckoutProductsConversion(checkoutProducts, getCookie2, setCookie2) {
    return __async(this, null, function* () {
      if (checkoutProducts) {
        const sovReqToken = yield getCookie2(sovReqTokenKey);
        const sovReqProductId = yield getCookie2(sovReqProductIdKey);
        if (sovReqToken && sovReqProductId) {
          yield setCookie2(sovReqTokenKey, "");
          yield setCookie2(sovReqProductIdKey, "");
          const pixelUrl = `https://press-order-api.sovendus.com/ext/${decodeURIComponent(
            sovReqProductId
          )}/image?sovReqToken=${decodeURIComponent(sovReqToken)}`;
          yield fetch(pixelUrl);
          return true;
        }
      }
      return false;
    });
  }
  function getOptimizeConfig(settings, country) {
    if (settings.globalEnabled !== false && settings.useGlobalId !== false && settings.globalId) {
      return settings.globalId;
    }
    if (country && settings.countrySpecificIds) {
      const countryElement = settings.countrySpecificIds[country];
      return (countryElement == null ? void 0 : countryElement.isEnabled) ? countryElement == null ? void 0 : countryElement.optimizeId : void 0;
    }
    return void 0;
  }
  function sovendusThankYou() {
    return __async(this, null, function* () {
      const config = window.sovThankyouConfig;
      window.sovThankyouStatus = {
        loadedOptimize: false,
        loadedVoucherNetwork: false,
        executedCheckoutProducts: false,
        sovThankyouConfigFound: false,
        countryCodePassedOnByPlugin: false
      };
      if (!config) {
        window.sovThankyouStatus.sovThankyouConfigFound = false;
        console.error("sovThankyouConfig is not defined");
        return;
      }
      window.sovThankyouStatus.sovThankyouConfigFound = true;
      if (config.consumerCountry === "UK") {
        config.consumerCountry = CountryCodes.GB;
      }
      const { optimizeId, checkoutProducts, voucherNetwork } = getSovendusConfig(
        config.settings,
        config.consumerCountry,
        config.consumerLanguage
      );
      handleVoucherNetwork(voucherNetwork, config, config.consumerCountry);
      window.sovThankyouStatus.executedCheckoutProducts = yield handleCheckoutProductsConversion(
        checkoutProducts,
        getCookie,
        setCookie
      );
      handleOptimizeConversion(optimizeId, config);
    });
  }
  function handleOptimizeConversion(optimizeId, config) {
    var _a;
    if (optimizeId) {
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.async = true;
      script.src = `https://www.sovopt.com/${optimizeId}/conversion/?ordervalue=${config.orderValue}&ordernumber=${config.orderId}&vouchercode=${(_a = config.usedCouponCodes) == null ? void 0 : _a[0]}&email=${config.consumerEmail}`;
      document.body.appendChild(script);
      window.sovThankyouStatus.loadedOptimize = true;
    }
  }
  function handleVoucherNetwork(voucherNetworkConfig, config, country) {
    var _a;
    if ((voucherNetworkConfig == null ? void 0 : voucherNetworkConfig.trafficSourceNumber) && voucherNetworkConfig.trafficMediumNumber) {
      window.sovIframes = window.sovIframes || [];
      window.sovIframes.push({
        trafficSourceNumber: voucherNetworkConfig.trafficSourceNumber,
        trafficMediumNumber: voucherNetworkConfig.trafficMediumNumber,
        sessionId: config.sessionId,
        timestamp: config.timestamp,
        orderId: config.orderId,
        orderValue: config.orderValue,
        orderCurrency: config.orderCurrency,
        usedCouponCode: (_a = config.usedCouponCodes) == null ? void 0 : _a[0],
        iframeContainerId: config.iframeContainerId,
        integrationType: config.integrationType
      });
      window.sovConsumer = {
        consumerFirstName: config.consumerFirstName,
        consumerLastName: config.consumerLastName,
        consumerEmail: config.consumerEmail,
        consumerStreet: config.consumerStreet,
        consumerStreetNumber: config.consumerStreetNumber,
        consumerZipcode: config.consumerZipcode,
        consumerCity: config.consumerCity,
        consumerCountry: country,
        consumerPhone: config.consumerPhone
      };
      const sovendusDiv = document.createElement("div");
      sovendusDiv.id = "sovendus-integration-container";
      const rootElement = config.settings.voucherNetwork.iframeContainerId && document.querySelector(config.settings.voucherNetwork.iframeContainerId);
      if (rootElement) {
        rootElement.appendChild(sovendusDiv);
      } else {
        document.body.appendChild(sovendusDiv);
      }
      const script = document.createElement("script");
      script.type = "text/javascript";
      script.async = true;
      script.src = "https://api.sovendus.com/sovabo/common/js/flexibleIframe.js";
      document.body.appendChild(script);
      window.sovThankyouStatus.loadedVoucherNetwork = true;
    }
  }
  const getCookie = (name) => {
    var _a;
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) {
      return (_a = parts.pop()) == null ? void 0 : _a.split(";").shift();
    }
    return void 0;
  };
  const setCookie = (name) => {
    const path = "/";
    const domain = window.location.hostname;
    const cookieString = `${name}=;secure;samesite=strict;max-age=Thu, 01 Jan 1970 00:00:00 UTC;domain=${domain};path=${path}`;
    document.cookie = cookieString;
    return "";
  };
  function getSovendusConfig(settings, country, language) {
    return {
      optimizeId: getOptimizeConfig(settings.optimize, country),
      voucherNetwork: getVoucherNetworkConfig(
        settings.voucherNetwork,
        country,
        language
      ),
      checkoutProducts: settings.checkoutProducts
    };
  }
  function getVoucherNetworkConfig(settings, country, language) {
    const languageSettings = getLanguageSettings(settings, country, language);
    if (!languageSettings || !languageSettings.isEnabled || !languageSettings.trafficMediumNumber || !languageSettings.trafficSourceNumber) {
      return void 0;
    }
    return languageSettings;
  }
  function getLanguageSettings(settings, country, language) {
    if (!country) {
      window.sovThankyouStatus.countryCodePassedOnByPlugin = false;
      return void 0;
    }
    window.sovThankyouStatus.countryCodePassedOnByPlugin = true;
    const countrySettings = settings.countries[country];
    const languagesSettings = countrySettings == null ? void 0 : countrySettings.languages;
    if (!languagesSettings) {
      return void 0;
    }
    const languagesAvailable = Object.keys(LANGUAGES_BY_COUNTRIES[country]);
    if ((languagesAvailable == null ? void 0 : languagesAvailable.length) === 1) {
      const language2 = languagesAvailable[0];
      const languageSettings = languagesSettings[language2];
      return languageSettings;
    }
    if ((languagesAvailable == null ? void 0 : languagesAvailable.length) > 1) {
      const languageKey = language || detectLanguageCode();
      const languageSettings = languagesSettings[languageKey];
      if (!languageSettings) {
        return void 0;
      }
      return languageSettings;
    }
    return void 0;
  }
  function detectLanguageCode() {
    const htmlLang = document.documentElement.lang.split("-")[0];
    if (htmlLang) {
      return htmlLang;
    }
    return navigator.language.split("-")[0];
  }
  void sovendusThankYou();
})();
//# sourceMappingURL=thankyou-page.js.map
